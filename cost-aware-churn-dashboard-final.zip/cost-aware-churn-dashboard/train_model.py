import json
import os

import joblib
import pandas as pd
from imblearn.over_sampling import SMOTE
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from xgboost import XGBClassifier


DATA_PATH = "data/Telco_customer_churn.xlsx"
MODEL_DIR = "models"

os.makedirs(MODEL_DIR, exist_ok=True)

# ==========================================================
# LOAD DATA
# ==========================================================

df = pd.read_excel(DATA_PATH)
target = "Churn Value"

# Target-related and identifier/post-churn columns are excluded.
drop_columns = [
    "CustomerID",
    "Count",
    "Country",
    "State",
    "City",
    "Zip Code",
    "Lat Long",
    "Latitude",
    "Longitude",
    "Churn Label",
    "Churn Score",
    "Churn Reason",
    "Churn Value"
]

X = df.drop(columns=drop_columns, errors="ignore").copy()
y = df[target].astype(int)

# Total Charges can contain blank strings in the raw Telco data.
X["Total Charges"] = pd.to_numeric(X["Total Charges"], errors="coerce")

# ==========================================================
# TRAIN / TEST SPLIT
# ==========================================================

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    stratify=y,
    random_state=42
)

categorical_columns = X_train.select_dtypes(include=["object"]).columns.tolist()
numeric_columns = X_train.select_dtypes(exclude=["object"]).columns.tolist()

# ==========================================================
# PREPROCESSING
# ==========================================================

try:
    encoder = OneHotEncoder(
        handle_unknown="ignore",
        sparse_output=False
    )
except TypeError:
    # Compatibility with older scikit-learn versions.
    encoder = OneHotEncoder(
        handle_unknown="ignore",
        sparse=False
    )

preprocessor = ColumnTransformer(
    transformers=[
        (
            "num",
            Pipeline([
                ("imputer", SimpleImputer(strategy="median")),
                ("scaler", StandardScaler())
            ]),
            numeric_columns
        ),
        (
            "cat",
            Pipeline([
                ("imputer", SimpleImputer(strategy="most_frequent")),
                ("encoder", encoder)
            ]),
            categorical_columns
        )
    ]
)

X_train_transformed = preprocessor.fit_transform(X_train)
X_test_transformed = preprocessor.transform(X_test)

# ==========================================================
# SMOTE — TRAINING DATA ONLY
# ==========================================================

smote = SMOTE(random_state=42)
X_train_balanced, y_train_balanced = smote.fit_resample(
    X_train_transformed,
    y_train
)

# ==========================================================
# XGBOOST MODEL
# ==========================================================

model = XGBClassifier(
    n_estimators=400,
    max_depth=4,
    learning_rate=0.05,
    subsample=0.90,
    colsample_bytree=0.90,
    eval_metric="logloss",
    random_state=42,
    n_jobs=4
)

model.fit(X_train_balanced, y_train_balanced)

# ==========================================================
# SAVE MODEL
# ==========================================================

joblib.dump(model, os.path.join(MODEL_DIR, "xgboost_model.pkl"))
joblib.dump(preprocessor, os.path.join(MODEL_DIR, "preprocessor.pkl"))

# Cost-aware operating point used by the dashboard.
with open(os.path.join(MODEL_DIR, "threshold.json"), "w", encoding="utf-8") as f:
    json.dump(
        {
            "threshold": 0.10,
            "fp_cost": 1,
            "fn_cost": 5
        },
        f,
        indent=2
    )

print("Training complete.")
print(f"Training rows: {len(X_train)}")
print(f"Test rows: {len(X_test)}")
print(f"Transformed features: {X_train_transformed.shape[1]}")
print("Saved:")
print("  models/xgboost_model.pkl")
print("  models/preprocessor.pkl")
print("  models/threshold.json")
