from flask import Flask, render_template, request, send_from_directory
import os
import json
import uuid
import pickle

import joblib
import numpy as np
import pandas as pd
import shap


app = Flask(__name__)

# ==========================================================
# PATHS
# ==========================================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_PATH = os.path.join(BASE_DIR, "models", "xgboost_model.pkl")
PREPROCESSOR_PATH = os.path.join(BASE_DIR, "models", "preprocessor.pkl")
THRESHOLD_PATH = os.path.join(BASE_DIR, "models", "threshold.json")
OUTPUT_DIR = os.path.join(BASE_DIR, "outputs")
os.makedirs(OUTPUT_DIR, exist_ok=True)

# ==========================================================
# MODEL / PREPROCESSOR
# ==========================================================

try:
    model = joblib.load(MODEL_PATH)
except Exception:
    with open(MODEL_PATH, "rb") as f:
        model = pickle.load(f)

preprocessor = joblib.load(PREPROCESSOR_PATH)

with open(THRESHOLD_PATH, "r", encoding="utf-8") as f:
    threshold_config = json.load(f)

COST_AWARE_THRESHOLD = float(threshold_config.get("threshold", 0.10))
FP_COST = float(threshold_config.get("fp_cost", 1))
FN_COST = float(threshold_config.get("fn_cost", 5))

# ==========================================================
# REQUIRED INPUT FEATURES
# ==========================================================

REQUIRED = [
    "Gender",
    "Senior Citizen",
    "Partner",
    "Dependents",
    "Tenure Months",
    "Phone Service",
    "Multiple Lines",
    "Internet Service",
    "Online Security",
    "Online Backup",
    "Device Protection",
    "Tech Support",
    "Streaming TV",
    "Streaming Movies",
    "Contract",
    "Paperless Billing",
    "Payment Method",
    "Monthly Charges",
    "Total Charges",
    "CLTV"
]

# ==========================================================
# COST-AWARE TEST-SET EXPERIMENT
# These are the held-out test-set results from the project
# experiment. They are not recalculated from an uploaded file.
# ==========================================================

COST_ANALYSIS = {
    "standard": {
        "threshold": 0.50,
        "fp": 157,
        "fn": 151,
        "precision": 0.5868,
        "recall": 0.5963,
        "f1": 0.5915,
        "cost": 912
    },
    "cost_aware": {
        "threshold": 0.10,
        "fp": 466,
        "fn": 21,
        "precision": 0.4310,
        "recall": 0.9439,
        "f1": 0.5918,
        "cost": 571
    }
}

COST_REDUCTION = round(
    (
        (COST_ANALYSIS["standard"]["cost"]
         - COST_ANALYSIS["cost_aware"]["cost"])
        / COST_ANALYSIS["standard"]["cost"]
    ) * 100,
    2
)

SENSITIVITY_DATA = [
    {"ratio": "1:1", "threshold": 0.61, "fp": 86, "fn": 191, "cost": 277},
    {"ratio": "3:1", "threshold": 0.19, "fp": 357, "fn": 45, "cost": 492},
    {"ratio": "5:1", "threshold": 0.10, "fp": 466, "fn": 21, "cost": 571},
    {"ratio": "7:1", "threshold": 0.10, "fp": 466, "fn": 21, "cost": 613},
    {"ratio": "10:1", "threshold": 0.06, "fp": 563, "fn": 9, "cost": 653}
]

# ==========================================================
# HELPERS
# ==========================================================

def friendly_feature_name(name):
    name = str(name).replace("cat__", "").replace("num__", "")
    if "_" in name:
        first, rest = name.split("_", 1)
        return f"{first}: {rest}"
    return name


def read_uploaded_file(file):
    filename = (file.filename or "").lower()

    if filename.endswith(".csv"):
        return pd.read_csv(file)

    if filename.endswith(".xlsx"):
        return pd.read_excel(file)

    raise ValueError("Please upload a CSV or XLSX file.")


def get_shap_array(raw_values, class_index=1):
    """Normalize SHAP output across common SHAP versions."""
    if isinstance(raw_values, list):
        if len(raw_values) > class_index:
            return np.asarray(raw_values[class_index])
        return np.asarray(raw_values[0])

    values = np.asarray(raw_values)

    if values.ndim == 3:
        # (samples, features, classes)
        return values[:, :, class_index]

    return values


def build_shap_explanations(X_transformed, probabilities, churn_indices):
    shap_global = []
    shap_local = []
    top_customer_probability = float(np.max(probabilities)) if len(probabilities) else 0.0
    top_customer_index = int(np.argmax(probabilities)) if len(probabilities) else 0

    try:
        feature_names = preprocessor.get_feature_names_out()
        explainer = shap.TreeExplainer(model)

        sample_size = min(300, len(X_transformed))
        sample_data = X_transformed[:sample_size]
        raw_global = explainer.shap_values(sample_data)
        global_values = get_shap_array(raw_global)

        if global_values.ndim == 1:
            global_values = global_values.reshape(1, -1)

        mean_abs_shap = np.mean(np.abs(global_values), axis=0)

        importance = pd.DataFrame({
            "feature": feature_names,
            "importance": mean_abs_shap
        }).sort_values("importance", ascending=False).head(10)

        shap_global = [
            {
                "feature": friendly_feature_name(row["feature"]),
                "importance": round(float(row["importance"]), 4)
            }
            for _, row in importance.iterrows()
        ]

        if len(churn_indices) > 0:
            sorted_indices = churn_indices[np.argsort(probabilities[churn_indices])[::-1]]
            top_customer_index = int(sorted_indices[0])
        else:
            top_customer_index = int(np.argmax(probabilities))

        top_customer_probability = float(probabilities[top_customer_index])

        customer_data = X_transformed[top_customer_index:top_customer_index + 1]
        raw_local = explainer.shap_values(customer_data)
        local_values = get_shap_array(raw_local)

        if local_values.ndim == 2:
            local_values = local_values[0]
        elif local_values.ndim > 2:
            local_values = local_values.reshape(local_values.shape[0], -1)[0]

        local_df = pd.DataFrame({
            "feature": feature_names,
            "shap": local_values
        })
        local_df["abs_shap"] = np.abs(local_df["shap"])
        local_df = local_df.sort_values("abs_shap", ascending=False).head(10)

        shap_local = [
            {
                "feature": friendly_feature_name(row["feature"]),
                "value": round(float(row["shap"]), 4),
                "direction": (
                    "Increases Churn Risk"
                    if float(row["shap"]) > 0
                    else "Decreases Churn Risk"
                )
            }
            for _, row in local_df.iterrows()
        ]

    except Exception as exc:
        print("SHAP ERROR:", exc)

    return shap_global, shap_local, top_customer_probability, top_customer_index


def build_results(df, probabilities):
    predictions = (probabilities >= COST_AWARE_THRESHOLD).astype(int)

    result = df.copy()
    result["Churn Probability"] = probabilities
    result["Prediction"] = np.where(predictions == 1, "Churn", "Stay")

    result["Risk Level"] = pd.cut(
        probabilities,
        bins=[-np.inf, 0.30, 0.70, np.inf],
        labels=["Low", "Medium", "High"]
    ).astype(str)

    churn_indices = np.where(predictions == 1)[0]
    priority = np.zeros(len(result), dtype=int)

    if len(churn_indices) > 0:
        sorted_indices = churn_indices[np.argsort(probabilities[churn_indices])[::-1]]
        for rank, idx in enumerate(sorted_indices, start=1):
            priority[idx] = rank

    result["Priority"] = priority
    result["Expected Churn Cost"] = probabilities * FN_COST

    return result, predictions, churn_indices


def build_retention_priorities(result, probabilities, predictions, budget_slots):
    """Select top predicted-churn customers under a limited intervention budget."""
    churn_indices = np.where(predictions == 1)[0]
    sorted_indices = churn_indices[np.argsort(probabilities[churn_indices])[::-1]] if len(churn_indices) else np.array([], dtype=int)

    selected_indices = sorted_indices[:budget_slots]
    selected_set = set(int(i) for i in selected_indices)

    priorities = []
    for rank, idx in enumerate(selected_indices, start=1):
        row = result.iloc[int(idx)]
        customer_id = row.get("CustomerID", f"Customer {int(idx) + 1}")
        priorities.append({
            "rank": int(rank),
            "customer_id": str(customer_id),
            "probability": round(float(probabilities[idx]) * 100, 2),
            "risk": str(row["Risk Level"]),
            "expected_cost": round(float(probabilities[idx] * FN_COST), 4),
            "action": "Prioritize retention intervention"
        })

    return priorities, len(selected_set), len(churn_indices)


def make_table_data(result):
    display_columns = []

    if "CustomerID" in result.columns:
        display_columns.append("CustomerID")

    display_columns.extend([
        "Churn Probability",
        "Prediction",
        "Risk Level",
        "Priority",
        "Expected Churn Cost"
    ])

    display_df = result[display_columns].copy()
    display_df = display_df.sort_values("Churn Probability", ascending=False).head(100)

    display_df["Churn Probability"] = (
        display_df["Churn Probability"] * 100
    ).round(2).astype(str) + "%"

    display_df["Expected Churn Cost"] = display_df["Expected Churn Cost"].round(3)

    return display_df.to_dict(orient="records")

# ==========================================================
# ROUTES
# ==========================================================

@app.route("/")
def home():
    return render_template("index.html", default_budget=10, error=None)


@app.route("/predict", methods=["POST"])
def predict():
    file = request.files.get("file")

    if file is None or not file.filename:
        return render_template(
            "index.html",
            default_budget=10,
            error="Please select a CSV or XLSX file."
        )

    try:
        budget_slots = int(request.form.get("budget", 10))
    except ValueError:
        budget_slots = 10

    budget_slots = max(1, min(budget_slots, 10000))

    try:
        df = read_uploaded_file(file)
    except Exception as exc:
        return render_template("index.html", default_budget=budget_slots, error=str(exc))

    missing = [column for column in REQUIRED if column not in df.columns]

    if missing:
        return render_template(
            "index.html",
            default_budget=budget_slots,
            error="Missing required columns: " + ", ".join(missing)
        )

    X = df[REQUIRED].copy()
    X["Total Charges"] = pd.to_numeric(X["Total Charges"], errors="coerce")

    try:
        X_transformed = preprocessor.transform(X)
    except Exception as exc:
        return render_template(
            "index.html",
            default_budget=budget_slots,
            error=f"Preprocessing error: {exc}"
        )

    try:
        probabilities = model.predict_proba(X_transformed)[:, 1]
    except Exception as exc:
        return render_template(
            "index.html",
            default_budget=budget_slots,
            error=f"Prediction error: {exc}"
        )

    result, predictions, churn_indices = build_results(df, probabilities)

    # SHAP explanations
    shap_global, shap_local, top_customer_probability, top_customer_index = build_shap_explanations(
        X_transformed,
        probabilities,
        churn_indices
    )

    # Dashboard statistics
    total_customers = len(result)
    predicted_churn = int(np.sum(predictions == 1))
    high_risk = int(np.sum(probabilities > 0.70))
    medium_risk = int(np.sum((probabilities > 0.30) & (probabilities <= 0.70)))
    low_risk = int(np.sum(probabilities <= 0.30))
    average_probability = round(float(np.mean(probabilities) * 100), 2) if len(probabilities) else 0.0

    # Limited-budget retention prioritization
    retention_priorities, selected_count, eligible_churn_count = build_retention_priorities(
        result,
        probabilities,
        predictions,
        budget_slots
    )

    # Save complete results for download
    output_name = f"churn_results_{uuid.uuid4().hex}.csv"
    output_path = os.path.join(OUTPUT_DIR, output_name)
    result.to_csv(output_path, index=False)

    return render_template(
        "result.html",
        total_customers=total_customers,
        predicted_churn=predicted_churn,
        high_risk=high_risk,
        medium_risk=medium_risk,
        low_risk=low_risk,
        average_probability=average_probability,
        threshold=COST_AWARE_THRESHOLD,
        fp_cost=FP_COST,
        fn_cost=FN_COST,
        table_data=make_table_data(result),
        shap_global=shap_global,
        shap_local=shap_local,
        top_customer_probability=round(top_customer_probability * 100, 2),
        cost_analysis=COST_ANALYSIS,
        cost_reduction=COST_REDUCTION,
        sensitivity_data=SENSITIVITY_DATA,
        retention_priorities=retention_priorities,
        budget_slots=budget_slots,
        selected_count=selected_count,
        eligible_churn_count=eligible_churn_count,
        download_file=output_name,
        top_customer_id=(
            str(result.iloc[top_customer_index].get("CustomerID", f"Customer {top_customer_index + 1}"))
            if len(result) else "N/A"
        )
    )


@app.route("/download/<filename>")
def download(filename):
    # Only allow generated CSV names from the output directory.
    if not filename.startswith("churn_results_") or not filename.endswith(".csv"):
        return "Invalid download file.", 400

    return send_from_directory(OUTPUT_DIR, filename, as_attachment=True)


if __name__ == "__main__":
    app.run(debug=True, host="127.0.0.1", port=5000)
